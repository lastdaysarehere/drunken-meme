from distutils.core import setup

setup(
	name		= '02exercicio',
	version		= '1.0.0',
	py_modules	= ['02'],
	author		= 'fernando',
	author_email	= 'fernando.bzx@gamail.com',
	url		= '***********************',
	description	= 'Um simples programa dee teste da função def e loop for',
)
